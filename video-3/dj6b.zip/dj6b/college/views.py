from django.shortcuts import render

# Create your views here.

def home(req):
    return render(req, "index.html", {"name":"Bla Bla"})

def about(req):
    return render(req, "about.html")

def contact(req):
    return render(req, "contact.html")

from django.apps import AppConfig


class CollegeConfig(AppConfig):
    name = 'college'

from django.contrib import admin
from django.urls import path
from django.urls.conf import include
from college import views
from django.views.generic.base import RedirectView

urlpatterns = [
    path('home/', views.home, name="home"),
    path('about/', views.about),
    path('contact/', views.contact),
    path('', RedirectView.as_view(url="home/")),    
]
